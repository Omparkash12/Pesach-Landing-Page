
import React from 'react';
import './App.css';
// import './Components/Custom.css'
// import Navbar1 from './Components/Navbar1';
// import Navbar2 from './Components/Navbar2';
// import GuitarSection from './Components/GuitarSection';
// import InstrumentSection from './Components/InstrumentSection';
// import GraphSection from './Components/GraphSection';
// import CardSection from './Components/CardSection';
// import SliderSection from './Components/SliderSection';
// import DashSection from './Components/DashSection';
// import DrumSection from './Components/DrumSection';
// import WarrantySection from './Components/WarrantySection';
// import Footer from './Components/Footer';
// import CopyrightFooter from './Components/CopyrightFooter';
import Home from './Pages/Home/Home/Home';

function App() {
  return (

    <> 

    <Home />  
      {/* <Navbar1 link1="NEWSLETTER" link2="SUPPORT" link3="UNITED STATES" link4="MY LYX PRO" />
      <Navbar2 link5="PRODUCTS" link6="SUPPORT" />
      <GuitarSection />
      <InstrumentSection />
      <SliderSection />
      <div className="container-fluid graphSection p-0 ">
        <GraphSection />
        <CardSection />
      </div>
      <DashSection />
      <DrumSection />
      <WarrantySection />
      <Footer />
      <CopyrightFooter /> */}
    </>
  );
}

export default App;
