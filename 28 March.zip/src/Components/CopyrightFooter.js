import React from 'react'

export default function CopyrightFooter() {
  return (
      <>
      <div className="container-fluid copyrightSection">
          <div className="container">
              <div className="row text-white py-4">
                  <div className="col-lg-6 col-md-6 col-sm-6 col-12 copyrightText">
                      <p className='py-2 m-0'>
                      © 2022 LyxPro | All rights reserved.
                      </p>
                  </div>

                  <div className="col-lg-6 col-md-6 col-sm-6 col-12 d-flex justify-content-end copyrightTerms">
                      <div className="copyrightLinks px-4">
                          <a className='text-white py-1' href="#">Terms</a>
                      </div>
                      <div className="copyrightLinks px-4">
                          <a className='text-white py-1' href="#">Privacy</a>
                      </div>
                      <div className="copyrightLinks px-4">
                          <a className='text-white py-1' href="#">Refund</a>
                      </div>
                  </div>
              </div>
          </div>
      </div>
      
      </>
  )
}
