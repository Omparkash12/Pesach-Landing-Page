import React from 'react'
import brandImg from '../images/brand-Img.png'


export default function Navbar2(props) {
    return (




        <div className="container-fluid p-0 navigationBar2 navContainerfluid diffBG">
            <div className="container width70 py-3">
                <nav className="navbar navbar-expand-lg">
                    <div className="container-fluid">
                        <div className="item1">
                            <a className="navbar-brand" href="#">
                                <img className='img-fluid' src={brandImg} alt="" />
                            </a>
                        </div>
                        <div className="item2">
                            <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                                <span className="navbar-toggler-icon"></span>
                            </button>
                            <div className="collapse navbar-collapse" id="navbarNav">
                                <ul className="navbar-nav">
                                    <li className="nav-item">
                                        <a className="nav-link active" aria-current="page" href="#">
                                            <span className='navIcons1'>{props.link5}</span></a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#"><span className='navIcons1'>{props.link6}</span></a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#"><span className='navIcons1'> WHERE TO BYE</span></a>
                                    </li>
                                </ul>

                                <div className="serachBar">
                                    <input className='serachBarInput' type="text" placeholder='Search' />
                                </div>

                                <div className="heart d-flex align-items-center ms-4">
                                    <a href="#">
                                        <span>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="29.66" height="24.96" viewBox="0 0 34 29.75">
                                                <path id="Icon_awesome-heart" data-name="Icon awesome-heart" d="M30.7,4.282a9.081,9.081,0,0,0-12.391.9L17,6.533,15.691,5.185A9.08,9.08,0,0,0,3.3,4.282a9.535,9.535,0,0,0-.657,13.806L15.492,31.355a2.082,2.082,0,0,0,3.008,0L31.35,18.087A9.529,9.529,0,0,0,30.7,4.282Z" transform="translate(0.001 -2.248)" fill="#ebebeb"></path>
                                            </svg>
                                        </span>
                                    </a>
                                </div>

                                <div className="navCart d-flex align-items-center ms-4">
                                    <a href="#">
                                        <span>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="30" viewBox="0 0 30 30">
                                                <g id="shopping_cart" transform="translate(-1 -1)">
                                                    <g id="Group_827" data-name="Group 827">
                                                        <path id="Path_6616" data-name="Path 6616" d="M30.783,8.377A1,1,0,0,0,30,8H7.681l-.53-3.178a3.187,3.187,0,0,0-1.6-2.164,1,1,0,0,0-.895,1.789,1.261,1.261,0,0,1,.52.7L7.521,19.205A4.7,4.7,0,0,0,12,23H24a4.937,4.937,0,0,0,4.649-3.7L30.975,9.225A1,1,0,0,0,30.783,8.377Z" fill="#ebebeb"></path>
                                                        <circle id="Ellipse_551" data-name="Ellipse 551" cx="3" cy="3" r="3" transform="translate(23 25)" fill="#ebebeb"></circle>
                                                        <circle id="Ellipse_552" data-name="Ellipse 552" cx="1" cy="1" r="1" transform="translate(25 27)" fill="#ebebeb"></circle>
                                                        <circle id="Ellipse_553" data-name="Ellipse 553" cx="3" cy="3" r="3" transform="translate(9 25)" fill="#ebebeb"></circle>
                                                        <circle id="Ellipse_554" data-name="Ellipse 554" cx="1" cy="1" r="1" transform="translate(11 27)" fill="#ebebeb"></circle>
                                                        <g id="Group_826" data-name="Group 826">
                                                            <path id="Path_6617" data-name="Path 6617" d="M5.1,4.553a1,1,0,0,1-.446-.105L1.553,2.895a1,1,0,0,1,.895-1.789L5.553,2.658A1,1,0,0,1,5.1,4.553Z" fill="#ebebeb"></path>
                                                        </g>
                                                    </g>
                                                </g>
                                            </svg>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    )
}
